package com.example.alumniassocaition1.repository;

// --- File: com/yourdomain/alumniapp/repository/CollegeRepository.java ---


import com.example.alumniassocaition1.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // Find a user by their unique email address (used for login and checks)
    Optional<User> findByEmail(String email);

    // Find all users belonging to a specific college (used by admin)
    List<User> findByCollegeCollegeId(Long collegeId);

    // Find users whose name contains a given string (case-insensitive search)
    List<User> findByNameContainingIgnoreCase(String name);

    /**
     * Checks if a user exists with the given email.
     * This method will be automatically implemented by Spring Data JPA.
     *
     * @param email the email to check for
     * @return true if a user with the given email exists, false otherwise
     */
    boolean existsByEmail(String email); // This was the missing method

    // Add other custom query methods if needed
}
