package com.example.alumniassocaition1.controller;


import com.example.alumniassocaition1.dto.ApiResponse;
import com.example.alumniassocaition1.dto.EventCreateRequest;
import com.example.alumniassocaition1.dto.EventDto;
import com.example.alumniassocaition1.service.EventService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
public class EventController {

    @Autowired
    private EventService eventService;

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<EventDto>> getAllEvents() {
        List<EventDto> events = eventService.getAllEvents();
        return ResponseEntity.ok(events);
    }

    @GetMapping("/{eventId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<EventDto> getEventById(@PathVariable Long eventId) {
        EventDto event = eventService.getEventById(eventId);
        return ResponseEntity.ok(event);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ALUMNUS', 'ADMIN')")
    public ResponseEntity<EventDto> createEvent(@Valid @RequestBody EventCreateRequest createRequest) {
        EventDto newEvent = eventService.createEvent(createRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(newEvent);
    }

    @PutMapping("/{eventId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<EventDto> updateEvent(@PathVariable Long eventId, @Valid @RequestBody EventCreateRequest updateRequest) {
        EventDto updatedEvent = eventService.updateEvent(eventId, updateRequest);
        return ResponseEntity.ok(updatedEvent);
    }

    @PatchMapping("/{eventId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<EventDto> patchEvent(@PathVariable Long eventId, @Valid @RequestBody EventCreateRequest updateRequest) {
        EventDto updatedEvent = eventService.updateEvent(eventId, updateRequest);
        return ResponseEntity.ok(updatedEvent);
    }


    @DeleteMapping("/{eventId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> deleteEvent(@PathVariable Long eventId) {
        eventService.deleteEvent(eventId);
        return ResponseEntity.ok(new ApiResponse(true, "Event deleted successfully."));
    }

    @PostMapping("/{eventId}/join")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> joinEvent(@PathVariable Long eventId) {
        eventService.joinEvent(eventId);
        return ResponseEntity.ok(new ApiResponse(true, "Successfully joined event."));
    }

    @DeleteMapping("/{eventId}/join")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> leaveEvent(@PathVariable Long eventId) {
        eventService.leaveEvent(eventId);
        return ResponseEntity.ok(new ApiResponse(true, "Successfully left event."));
    }
}
