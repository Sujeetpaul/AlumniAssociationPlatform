package com.example.alumniassocaition1.repository;

import com.example.alumniassocaition1.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
    List<Event> findByCollegeCollegeId(Long collegeId);

    List<Event> findByCreatedByUserId(Long userId);

    List<Event> findByEventDateAfter(LocalDateTime date);
    // Add custom query methods if needed
}
