package com.example.alumniassocaition1.dto.post;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PostCreateRequest {
    @NotBlank
    private String content;
    // imageUrl is removed. The backend will handle file upload and generate the URL.
}
