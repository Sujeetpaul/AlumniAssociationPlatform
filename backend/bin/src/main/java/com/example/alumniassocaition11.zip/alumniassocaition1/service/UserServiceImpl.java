package com.example.alumniassocaition1.service;

import com.example.alumniassocaition1.dto.UserProfileDto;
import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import com.example.alumniassocaition1.dto.UserUpdateRequest;
import com.example.alumniassocaition1.entity.User;
import com.example.alumniassocaition1.entity.UserFollow;
import com.example.alumniassocaition1.entity.UserFollowId;
import com.example.alumniassocaition1.exception.ResourceNotFoundException;
import com.example.alumniassocaition1.repository.UserFollowRepository;
import com.example.alumniassocaition1.repository.UserRepository;
// Removed unused import: import com.example.alumniassocaition1.service.UserService;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException; // Import AccessDeniedException
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.authority.SimpleGrantedAuthority; // Import SimpleGrantedAuthority
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
// Fixed: Implement the UserService interface, not UserDetailsService directly here
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserFollowRepository userFollowRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, UserFollowRepository userFollowRepository) {
        this.userRepository = userRepository;
        this.userFollowRepository = userFollowRepository;
    }

    private User getCurrentAuthenticatedUserInternal() { // Renamed to avoid conflict if needed elsewhere
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || "anonymousUser".equals(authentication.getPrincipal())) {
            // Throw AccessDeniedException or a custom exception if authentication is required but missing
            throw new AccessDeniedException("User not authenticated");
        }
        Object principal = authentication.getPrincipal();
        String email;
        if (principal instanceof UserDetails) {
            email = ((UserDetails) principal).getUsername();
        } else {
            email = principal.toString(); // Fallback, might not be email
        }
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email + " (Principal: " + principal.getClass() + ")"));
    }

    // Implementation for UserDetailsService interface method
    @Override
    @Transactional(readOnly = true) // Good practice to make read-only transactions explicit
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPasswordHash(),
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase())));
    }

    // Implementation for UserService interface methods
    @Override
    @Transactional(readOnly = true)
    public UserProfileDto getUserProfile(Long userId) throws ResourceNotFoundException {
        User user = findUserById(userId);
        return mapUserToProfileDto(user);
    }

    @Override
    @Transactional(readOnly = true)
    public UserProfileDto getCurrentUserProfile() {
        User currentUser = getCurrentAuthenticatedUserInternal();
        return mapUserToProfileDto(currentUser);
    }

    @Override
    @Transactional
    public UserProfileDto updateUserProfile(UserUpdateRequest updateRequest) {
        User currentUser = getCurrentAuthenticatedUserInternal();
        if (updateRequest.getName() != null) currentUser.setName(updateRequest.getName());
        if (updateRequest.getHeadline() != null) currentUser.setProfileHeadline(updateRequest.getHeadline());
        if (updateRequest.getLocation() != null) currentUser.setProfileLocation(updateRequest.getLocation());
        if (updateRequest.getAbout() != null) currentUser.setProfileAbout(updateRequest.getAbout());

        User updatedUser = userRepository.save(currentUser);
        return mapUserToProfileDto(updatedUser);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserSummaryDto> getFollowers(Long userId) throws ResourceNotFoundException {
        User user = findUserById(userId);
        return userFollowRepository.findByIdFollowingId(user.getUserId()).stream()
                .map(UserFollow::getFollower)
                .map(this::mapUserToSummaryDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserSummaryDto> getFollowing(Long userId) throws ResourceNotFoundException {
        User user = findUserById(userId);
        return userFollowRepository.findByIdFollowerId(user.getUserId()).stream()
                .map(UserFollow::getFollowing)
                .map(this::mapUserToSummaryDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void followUser(Long userIdToFollow) throws ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUserInternal();
        User userToFollow = findUserById(userIdToFollow);

        if (currentUser.getUserId().equals(userToFollow.getUserId())) {
            throw new IllegalArgumentException("Cannot follow yourself.");
        }

        UserFollowId followId = new UserFollowId(currentUser.getUserId(), userToFollow.getUserId());
        if (userFollowRepository.existsById(followId)) {
            return; // Already following
        }

        UserFollow userFollow = new UserFollow();
        userFollow.setId(followId);
        userFollow.setFollower(currentUser);
        userFollow.setFollowing(userToFollow);
        userFollowRepository.save(userFollow);
    }

    @Override
    @Transactional
    public void unfollowUser(Long userIdToUnfollow) throws ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUserInternal();
        User userToUnfollow = findUserById(userIdToUnfollow);
        UserFollowId followId = new UserFollowId(currentUser.getUserId(), userToUnfollow.getUserId());
        // Optional: Check if the follow exists before deleting
        // if (!userFollowRepository.existsById(followId)) {
        //     return; // Or throw exception
        // }
        userFollowRepository.deleteById(followId);
    }

    @Override
    @Transactional(readOnly = true) // Mark as read-only
    public User findUserById(Long userId) throws ResourceNotFoundException {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
    }

    @Override
    @Transactional(readOnly = true) // Mark as read-only
    public User findUserByEmail(String email) throws ResourceNotFoundException {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
    }

    // Helper methods remain private
    private UserProfileDto mapUserToProfileDto(User user) {
        UserProfileDto dto = new UserProfileDto();
        BeanUtils.copyProperties(user, dto);
        dto.setId(user.getUserId());
        dto.setProfilePictureUrl(user.getProfilePictureUrl());
        // Consider potential NullPointerException if user/repo is null, though unlikely here
        dto.setFollowersCount(userFollowRepository.countByIdFollowingId(user.getUserId()));
        dto.setFollowingCount(userFollowRepository.countByIdFollowerId(user.getUserId()));
        return dto;
    }

    private UserSummaryDto mapUserToSummaryDto(User user) {
        UserSummaryDto dto = new UserSummaryDto();
        BeanUtils.copyProperties(user, dto);
        dto.setId(user.getUserId());
        return dto;
    }
}

