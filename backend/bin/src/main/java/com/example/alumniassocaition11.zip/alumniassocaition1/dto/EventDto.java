package com.example.alumniassocaition1.dto;

import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class EventDto {
    private Long id;
    private String title;
    private String description;
    private LocalDateTime date;
    private String location;
    private UserSummaryDto createdBy;
    private Long collegeId;
    private List<UserSummaryDto> attendees;
    private boolean isAttending;
    private LocalDateTime createdAt;
}