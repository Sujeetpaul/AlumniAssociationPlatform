package com.example.alumniassocaition1.service;

import com.example.alumniassocaition1.dto.EventCreateRequest;
import com.example.alumniassocaition1.dto.EventDto;
import com.example.alumniassocaition1.exception.ResourceNotFoundException;

import java.util.List;

public interface EventService {
    List<EventDto> getAllEvents();

    EventDto getEventById(Long eventId) throws ResourceNotFoundException;

    EventDto createEvent(EventCreateRequest createRequest);

    EventDto updateEvent(Long eventId, EventCreateRequest updateRequest) throws ResourceNotFoundException;

    void deleteEvent(Long eventId) throws ResourceNotFoundException;

    void joinEvent(Long eventId) throws ResourceNotFoundException;

    void leaveEvent(Long eventId) throws ResourceNotFoundException; // Added exception
}

