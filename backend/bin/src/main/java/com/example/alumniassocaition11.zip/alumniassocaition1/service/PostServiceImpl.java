package com.example.alumniassocaition1.service;
import com.example.alumniassocaition1.dto.post.PostCreateRequest;
import com.example.alumniassocaition1.dto.post.PostDto;
import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import com.example.alumniassocaition1.entity.Post;
import com.example.alumniassocaition1.entity.PostLike;
import com.example.alumniassocaition1.entity.PostLikeId;
import com.example.alumniassocaition1.entity.User;
import com.example.alumniassocaition1.exception.FileStorageException; // Import custom exceptions
import com.example.alumniassocaition1.exception.ResourceNotFoundException;
import com.example.alumniassocaition1.repository.CommentRepository;
import com.example.alumniassocaition1.repository.PostLikeRepository;
import com.example.alumniassocaition1.repository.PostRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Service
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;
    private final PostLikeRepository postLikeRepository;
    private final CommentRepository commentRepository;
    private final UserService userService;
    private final FileStorageService fileStorageService;

    @Autowired
    public PostServiceImpl(PostRepository postRepository, PostLikeRepository postLikeRepository,
                           CommentRepository commentRepository, UserService userService,
                           FileStorageService fileStorageService) {
        this.postRepository = postRepository;
        this.postLikeRepository = postLikeRepository;
        this.commentRepository = commentRepository;
        this.userService = userService;
        this.fileStorageService = fileStorageService;
    }

    private User getCurrentAuthenticatedUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username;
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else if (principal != null) {
            username = principal.toString();
        }
        else {
            throw new AccessDeniedException("User authentication not found.");
        }
        return userService.findUserByEmail(username);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PostDto> getAllPosts(Pageable pageable) {
        User currentUser = getCurrentAuthenticatedUser();
        return postRepository.findAll(pageable)
                .map(post -> mapPostToDto(post, currentUser));
    }

    @Override
    @Transactional(readOnly = true)
    public PostDto getPostById(Long postId) throws ResourceNotFoundException{
        User currentUser = getCurrentAuthenticatedUser();
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
        return mapPostToDto(post, currentUser);
    }

    @Override
    @Transactional
    public PostDto createPost(PostCreateRequest createRequest, MultipartFile imageFile) throws FileStorageException {
        User currentUser = getCurrentAuthenticatedUser();
        if (!("alumnus".equalsIgnoreCase(currentUser.getRole()) || "admin".equalsIgnoreCase(currentUser.getRole()))) {
            throw new AccessDeniedException("User does not have permission to create posts.");
        }

        Post post = new Post();
        post.setContent(createRequest.getContent());
        post.setAuthor(currentUser);

        if (imageFile != null && !imageFile.isEmpty()) {
            String fileName = fileStorageService.storeFile(imageFile);
            // Ensure this path matches SecurityConfig and Controller endpoint
            String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/api/posts/uploads/") // Match the serving endpoint path
                    .path(fileName)
                    .toUriString();
            post.setImageUrl(fileDownloadUri);
        }

        Post savedPost = postRepository.save(post);
        return mapPostToDto(savedPost, currentUser);
    }

    @Override
    @Transactional
    public PostDto updatePost(Long postId, PostCreateRequest updateRequest, MultipartFile imageFile) throws FileStorageException, ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUser();
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));

        if (!post.getAuthor().getUserId().equals(currentUser.getUserId())) {
            throw new AccessDeniedException("User does not have permission to update this post.");
        }
        post.setContent(updateRequest.getContent());

        if (imageFile != null && !imageFile.isEmpty()) {
            if (post.getImageUrl() != null && !post.getImageUrl().isBlank()) {
                try {
                    String oldFileName = post.getImageUrl().substring(post.getImageUrl().lastIndexOf("/") + 1);
                    fileStorageService.deleteFile(oldFileName);
                } catch (Exception e) {
                    System.err.println("Could not delete old file: " + post.getImageUrl() + " Error: " + e.getMessage());
                }
            }
            String newFileName = fileStorageService.storeFile(imageFile);
            String newFileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/api/posts/uploads/") // Match the serving endpoint path
                    .path(newFileName)
                    .toUriString();
            post.setImageUrl(newFileDownloadUri);
        }

        Post updatedPost = postRepository.save(post);
        return mapPostToDto(updatedPost, currentUser);
    }

    @Override
    @Transactional
    public void deletePost(Long postId) throws ResourceNotFoundException{
        User currentUser = getCurrentAuthenticatedUser();
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));

        if (!(post.getAuthor().getUserId().equals(currentUser.getUserId()) || "admin".equalsIgnoreCase(currentUser.getRole()))) {
            throw new AccessDeniedException("User does not have permission to delete this post.");
        }

        String imageUrl = post.getImageUrl();
        postRepository.delete(post);

        if (imageUrl != null && !imageUrl.isBlank()) {
            try {
                String fileName = imageUrl.substring(imageUrl.lastIndexOf("/") + 1);
                fileStorageService.deleteFile(fileName);
            } catch (Exception e) {
                System.err.println("Could not delete file: " + imageUrl + " Error: " + e.getMessage());
            }
        }
    }

    @Override
    @Transactional
    public void likePost(Long postId) throws ResourceNotFoundException{
        User currentUser = getCurrentAuthenticatedUser();
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));

        PostLikeId likeId = new PostLikeId(post.getPostId(), currentUser.getUserId());
        if (postLikeRepository.existsById(likeId)) {
            return;
        }
        PostLike postLike = new PostLike();
        postLike.setId(likeId);
        postLike.setPost(post);
        postLike.setUser(currentUser);
        postLikeRepository.save(postLike);
    }

    @Override
    @Transactional
    public void unlikePost(Long postId) throws ResourceNotFoundException { // Added throws clause
        User currentUser = getCurrentAuthenticatedUser();
        // Check if post exists before creating ID for deletion
        if (!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("Post", "id", postId);
        }
        PostLikeId likeId = new PostLikeId(postId, currentUser.getUserId());
        // Optional: Check if the like exists before trying to delete
        // if (!postLikeRepository.existsById(likeId)) {
        //     return; // Or throw exception if unliking a non-liked post is an error
        // }
        postLikeRepository.deleteById(likeId);
    }

    private PostDto mapPostToDto(Post post, User currentUser) {
        PostDto dto = new PostDto();
        BeanUtils.copyProperties(post, dto);
        dto.setId(post.getPostId());
        dto.setImageUrl(post.getImageUrl());

        if (post.getAuthor() != null) {
            UserSummaryDto authorDto = new UserSummaryDto();
            BeanUtils.copyProperties(post.getAuthor(), authorDto);
            authorDto.setId(post.getAuthor().getUserId());
            dto.setAuthor(authorDto);
        }
        dto.setLikesCount(postLikeRepository.countByIdPostId(post.getPostId()));
        dto.setCommentsCount(commentRepository.countByPostPostId(post.getPostId()));
        if(currentUser != null) {
            dto.setLikedByCurrentUser(postLikeRepository.existsByIdPostIdAndIdUserId(post.getPostId(), currentUser.getUserId()));
        } else {
            dto.setLikedByCurrentUser(false);
        }
        return dto;
    }
}
