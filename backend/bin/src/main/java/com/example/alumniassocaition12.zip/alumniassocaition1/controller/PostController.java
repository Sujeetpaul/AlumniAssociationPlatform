package com.example.alumniassocaition1.controller; // Or your actual package

import com.example.alumniassocaition1.dto.ApiResponse;
import com.example.alumniassocaition1.dto.post.PostCreateRequest;
import com.example.alumniassocaition1.dto.post.PostDto;
import com.example.alumniassocaition1.service.PostService;
import com.example.alumniassocaition1.service.FileStorageService;
import com.example.alumniassocaition1.exception.MyFileNotFoundException;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
// Correct import for Spring's Resource
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
// Removed: import org.springframework.web.servlet.support.ServletUriComponentsBuilder; // Not used directly in this controller

import jakarta.servlet.http.HttpServletRequest; // Correct import for HttpServletRequest
import java.io.IOException;


@RestController
@RequestMapping("/api/posts")
public class PostController {

    @Autowired
    private PostService postService;

    @Autowired
    private FileStorageService fileStorageService;

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Page<PostDto>> getAllPosts(@PageableDefault(size = 10, sort = "createdAt,desc") Pageable pageable) {
        Page<PostDto> posts = postService.getAllPosts(pageable);
        return ResponseEntity.ok(posts);
    }

    @GetMapping("/{postId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PostDto> getPostById(@PathVariable Long postId) {
        PostDto post = postService.getPostById(postId);
        return ResponseEntity.ok(post);
    }

    @PostMapping(consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @PreAuthorize("hasAnyRole('ALUMNUS', 'ADMIN')")
    public ResponseEntity<PostDto> createPost(
            @Valid @RequestPart("postData") PostCreateRequest createRequest,
            @RequestPart(value = "imageFile", required = false) MultipartFile imageFile) {
        PostDto newPost = postService.createPost(createRequest, imageFile);
        return ResponseEntity.status(HttpStatus.CREATED).body(newPost);
    }

    @PutMapping(value = "/{postId}", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PostDto> updatePost(
            @PathVariable Long postId,
            @Valid @RequestPart("postData") PostCreateRequest updateRequest,
            @RequestPart(value = "imageFile", required = false) MultipartFile imageFile) {
        PostDto updatedPost = postService.updatePost(postId, updateRequest, imageFile);
        return ResponseEntity.ok(updatedPost);
    }

    @PatchMapping(value = "/{postId}", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PostDto> patchPost(
            @PathVariable Long postId,
            @Valid @RequestPart("postData") PostCreateRequest updateRequest,
            @RequestPart(value = "imageFile", required = false) MultipartFile imageFile) {
        PostDto updatedPost = postService.updatePost(postId, updateRequest, imageFile);
        return ResponseEntity.ok(updatedPost);
    }


    @DeleteMapping("/{postId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> deletePost(@PathVariable Long postId) {
        postService.deletePost(postId);
        return ResponseEntity.ok(new ApiResponse(true, "Post deleted successfully."));
    }

    @PostMapping("/{postId}/like")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> likePost(@PathVariable Long postId) {
        postService.likePost(postId);
        return ResponseEntity.ok(new ApiResponse(true, "Post liked."));
    }

    @DeleteMapping("/{postId}/like")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> unlikePost(@PathVariable Long postId) {
        postService.unlikePost(postId);
        return ResponseEntity.ok(new ApiResponse(true, "Post unliked."));
    }

    // Endpoint to serve uploaded files (e.g., images for posts)
    // This path (/uploads/**) should match the path used in PostServiceImpl when constructing imageUrl
    // and the resource handler in SecurityConfig
    @GetMapping("/uploads/{filename:.+}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename, HttpServletRequest request) {
        // Ensure 'resource' is explicitly typed as org.springframework.core.io.Resource
        org.springframework.core.io.Resource resource;
        try {
            resource = fileStorageService.loadFileAsResource(filename);
        } catch (MyFileNotFoundException ex) {
            System.err.println("File not found: " + filename + " - " + ex.getMessage());
            return ResponseEntity.notFound().build();
        }

        String contentType = null;
        try {
            // These methods are available on org.springframework.core.io.Resource
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            System.out.println("Could not determine file type for: " + filename + ". Error: " + ex.getMessage());
        }

        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}
