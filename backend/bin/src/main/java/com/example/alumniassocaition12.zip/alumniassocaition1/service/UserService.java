package com.example.alumniassocaition1.service;

// --- File: com/yourdomain/alumniapp/service/UserService.java ---


import com.example.alumniassocaition1.dto.user.UserProfileDto;
import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import com.example.alumniassocaition1.dto.user.UserUpdateRequest;
import com.example.alumniassocaition1.entity.User;
import com.example.alumniassocaition1.exception.ResourceNotFoundException; // Import custom exceptions
import org.springframework.security.core.userdetails.UserDetailsService;
// Removed @Service annotation from interface
import java.util.List;

public interface UserService extends UserDetailsService { // Extends UserDetailsService for Spring Security integration
    UserProfileDto getUserProfile(Long userId) throws ResourceNotFoundException; // Added exception

    UserProfileDto getCurrentUserProfile();

    UserProfileDto updateUserProfile(UserUpdateRequest updateRequest); // Consider how profile pic updates are handled

    List<UserSummaryDto> getFollowers(Long userId) throws ResourceNotFoundException; // Added exception

    List<UserSummaryDto> getFollowing(Long userId) throws ResourceNotFoundException; // Added exception

    void followUser(Long userIdToFollow) throws ResourceNotFoundException; // Added exception

    void unfollowUser(Long userIdToUnfollow) throws ResourceNotFoundException; // Added exception

    User findUserById(Long userId) throws ResourceNotFoundException; // Added exception

    User findUserByEmail(String email) throws ResourceNotFoundException; // Added exception
}
