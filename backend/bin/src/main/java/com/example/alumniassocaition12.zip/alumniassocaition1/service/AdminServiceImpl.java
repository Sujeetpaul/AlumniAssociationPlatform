package com.example.alumniassocaition1.service;

import com.example.alumniassocaition1.dto.user.AdminUserCreateRequest;
import com.example.alumniassocaition1.dto.user.UserStatusUpdateRequest;
import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import com.example.alumniassocaition1.entity.College;
import com.example.alumniassocaition1.entity.Event;
import com.example.alumniassocaition1.entity.User;
import com.example.alumniassocaition1.exception.ResourceNotFoundException;
import com.example.alumniassocaition1.repository.EventRepository;
import com.example.alumniassocaition1.repository.UserRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final EventRepository eventRepository;
    private final UserService userService; // To get current admin user details
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AdminServiceImpl(UserRepository userRepository, EventRepository eventRepository, UserService userService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.eventRepository = eventRepository;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    private User getCurrentAdminUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username;
        if (principal instanceof UserDetails) {
            username = ((UserDetails)principal).getUsername();
        } else if (principal != null) {
            username = principal.toString();
        }
        else {
            throw new AccessDeniedException("User authentication not found.");
        }
        User adminUser = userService.findUserByEmail(username); // Throws ResourceNotFound if user doesn't exist
        if (!"admin".equalsIgnoreCase(adminUser.getRole())) {
            throw new AccessDeniedException("User is not an admin.");
        }
        return adminUser;
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserSummaryDto> getAllUsersForAdminCollege() {
        User adminUser = getCurrentAdminUser();
        College adminCollege = adminUser.getCollege();
        if (adminCollege == null) {
            // Maybe throw IllegalStateException or return empty list depending on requirements
            throw new IllegalStateException("Admin user is not associated with a college.");
        }
        return userRepository.findByCollegeCollegeId(adminCollege.getCollegeId()).stream()
                .map(this::mapUserToSummaryDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserSummaryDto adminAddUser(AdminUserCreateRequest createRequest) {
        User adminUser = getCurrentAdminUser();
        College adminCollege = adminUser.getCollege();
        if (adminCollege == null) {
            throw new IllegalStateException("Admin user is not associated with a college.");
        }

        // Use existsByEmail for efficiency if just checking existence
        if (userRepository.existsByEmail(createRequest.getEmail())) {
            throw new IllegalArgumentException("User with email " + createRequest.getEmail() + " already exists.");
        }

        User newUser = new User();
        newUser.setName(createRequest.getName());
        newUser.setEmail(createRequest.getEmail());
        newUser.setPasswordHash(passwordEncoder.encode(createRequest.getPassword()));
        newUser.setRole(createRequest.getRole()); // Ensure role is valid ("student" or "alumnus")
        newUser.setStatus(createRequest.getStatus() != null ? createRequest.getStatus() : "active"); // Ensure status is valid
        newUser.setCollege(adminCollege);

        User savedUser = userRepository.save(newUser);
        return mapUserToSummaryDto(savedUser);
    }

    @Override
    @Transactional
    public void adminRemoveUser(Long userId) throws ResourceNotFoundException {
        User adminUser = getCurrentAdminUser();
        User userToRemove = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        // Check if admin and user belong to the same college
        if (userToRemove.getCollege() == null || adminUser.getCollege() == null ||
                !userToRemove.getCollege().getCollegeId().equals(adminUser.getCollege().getCollegeId())) {
            throw new AccessDeniedException("Admin cannot remove users from other colleges or user/admin not associated with a college.");
        }
        // Prevent admin from removing themselves
        if (userToRemove.getUserId().equals(adminUser.getUserId())) {
            throw new AccessDeniedException("Admin cannot remove themselves.");
        }

        userRepository.delete(userToRemove);
    }

    @Override
    @Transactional
    public UserSummaryDto adminUpdateUserStatus(Long userId, UserStatusUpdateRequest statusUpdateRequest) throws ResourceNotFoundException {
        User adminUser = getCurrentAdminUser();
        User userToUpdate = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        if (userToUpdate.getCollege() == null || adminUser.getCollege() == null ||
                !userToUpdate.getCollege().getCollegeId().equals(adminUser.getCollege().getCollegeId())) {
            throw new AccessDeniedException("Admin cannot update status for users from other colleges or user/admin not associated with a college.");
        }

        // Optional: Validate the status string
        String newStatus = statusUpdateRequest.getStatus();
        if (!("active".equalsIgnoreCase(newStatus) || "inactive".equalsIgnoreCase(newStatus))) {
            throw new IllegalArgumentException("Invalid status value: " + newStatus);
        }
        userToUpdate.setStatus(newStatus);

        User updatedUser = userRepository.save(userToUpdate);
        return mapUserToSummaryDto(updatedUser);
    }

    @Override
    @Transactional
    public void adminRemoveEvent(Long eventId) throws ResourceNotFoundException {
        getCurrentAdminUser(); // Ensures user is admin
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));
        // Check if admin should only be able to delete events from their own college?
        // If so, add check: event.getCollege().getCollegeId().equals(adminUser.getCollege().getCollegeId())
        eventRepository.delete(event);
    }

    private UserSummaryDto mapUserToSummaryDto(User user) {
        UserSummaryDto dto = new UserSummaryDto();
        BeanUtils.copyProperties(user, dto); // Be careful with passwordHash if included in summary
        dto.setId(user.getUserId());
        dto.setEmail(user.getEmail());
        dto.setRole(user.getRole());
        // Add status if needed: dto.setStatus(user.getStatus());
        return dto;
    }
}

