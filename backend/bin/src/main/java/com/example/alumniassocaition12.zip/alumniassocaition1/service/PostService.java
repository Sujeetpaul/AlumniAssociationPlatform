package com.example.alumniassocaition1.service;

import com.example.alumniassocaition1.dto.post.PostCreateRequest;
import com.example.alumniassocaition1.dto.post.PostDto;
import com.example.alumniassocaition1.exception.FileStorageException; // Import custom exceptions
import com.example.alumniassocaition1.exception.ResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

public interface PostService {
    Page<PostDto> getAllPosts(Pageable pageable);

    PostDto getPostById(Long postId) throws ResourceNotFoundException;

    PostDto createPost(PostCreateRequest createRequest, MultipartFile imageFile) throws FileStorageException;

    PostDto updatePost(Long postId, PostCreateRequest updateRequest, MultipartFile imageFile) throws FileStorageException, ResourceNotFoundException;

    void deletePost(Long postId) throws ResourceNotFoundException;

    void likePost(Long postId) throws ResourceNotFoundException;

    void unlikePost(Long postId) throws ResourceNotFoundException; // Added exception
}

