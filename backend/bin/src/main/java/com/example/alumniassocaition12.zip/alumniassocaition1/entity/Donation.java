package com.example.alumniassocaition1.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "donations")
public class Donation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donation_id")
    private Long donationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false) // The donor
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "college_id", nullable = false) // The recipient college
    private College college;

    @Column(nullable = false)
    private BigDecimal amount;

    @Column(nullable = false) // e.g., "USD", "INR"
    private String currency;

    @Lob
    @Column(name = "payment_method_details") // Placeholder for actual payment info
    private String paymentMethodDetails;

    @Column(name = "transaction_id") // From payment gateway
    private String transactionId;

    @Column(nullable = false) // e.g., 'pending', 'successful', 'failed'
    private String status;

    @Column(name = "donated_at", updatable = false)
    private LocalDateTime donatedAt;

    @PrePersist
    protected void onCreate() {
        donatedAt = LocalDateTime.now();
    }
}
