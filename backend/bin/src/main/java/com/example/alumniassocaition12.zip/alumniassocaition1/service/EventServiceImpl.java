package com.example.alumniassocaition1.service;

import com.example.alumniassocaition1.dto.EventCreateRequest;
import com.example.alumniassocaition1.dto.EventDto;
import com.example.alumniassocaition1.dto.user.UserSummaryDto;
import com.example.alumniassocaition1.entity.Event;
import com.example.alumniassocaition1.entity.EventAttendee;
import com.example.alumniassocaition1.entity.EventAttendeeId;
import com.example.alumniassocaition1.entity.User; // Import User entity
import com.example.alumniassocaition1.exception.ResourceNotFoundException;
import com.example.alumniassocaition1.repository.EventAttendeeRepository;
import com.example.alumniassocaition1.repository.EventRepository;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepository;
    private final EventAttendeeRepository eventAttendeeRepository;
    private final UserService userService;

    @Autowired
    public EventServiceImpl(EventRepository eventRepository, EventAttendeeRepository eventAttendeeRepository, UserService userService) {
        this.eventRepository = eventRepository;
        this.eventAttendeeRepository = eventAttendeeRepository;
        this.userService = userService;
    }

    private User getCurrentAuthenticatedUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username;
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else if (principal != null) {
            username = principal.toString();
        }
        else {
            throw new AccessDeniedException("User authentication not found.");
        }
        return userService.findUserByEmail(username);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventDto> getAllEvents() {
        User currentUser = getCurrentAuthenticatedUser();
        return eventRepository.findAll().stream()
                .map(event -> mapEventToDto(event, currentUser))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public EventDto getEventById(Long eventId) throws ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUser();
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));
        return mapEventToDto(event, currentUser);
    }

    @Override
    @Transactional
    public EventDto createEvent(EventCreateRequest createRequest) {
        User currentUser = getCurrentAuthenticatedUser();
        // Fixed: Compare role string, not cloned object
        if (!("alumnus".equalsIgnoreCase(currentUser.getRole()) || "admin".equalsIgnoreCase(currentUser.getRole()))) {
            throw new AccessDeniedException("User does not have permission to create events.");
        }

        Event event = new Event();
        BeanUtils.copyProperties(createRequest, event);
        event.setCreatedBy(currentUser);
        event.setCollege(currentUser.getCollege());

        Event savedEvent = eventRepository.save(event);
        return mapEventToDto(savedEvent, currentUser);
    }

    @Override
    @Transactional
    public EventDto updateEvent(Long eventId, EventCreateRequest updateRequest) throws ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUser();
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));

        if (!(event.getCreatedBy().getUserId().equals(currentUser.getUserId()) || "admin".equalsIgnoreCase(currentUser.getRole()))) {
            throw new AccessDeniedException("User does not have permission to update this event.");
        }

        BeanUtils.copyProperties(updateRequest, event, "id", "createdBy", "college", "createdAt");
        Event updatedEvent = eventRepository.save(event);
        return mapEventToDto(updatedEvent, currentUser);
    }

    @Override
    @Transactional
    public void deleteEvent(Long eventId) throws ResourceNotFoundException {
        User currentUser = getCurrentAuthenticatedUser();
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));

        if (!(event.getCreatedBy().getUserId().equals(currentUser.getUserId()) || "admin".equalsIgnoreCase(currentUser.getRole()))) {
            throw new AccessDeniedException("User does not have permission to delete this event.");
        }
        eventRepository.delete(event);
    }

    @Override
    @Transactional
    public void joinEvent(Long eventId) throws ResourceNotFoundException{
        User currentUser = getCurrentAuthenticatedUser();
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));

        EventAttendeeId attendeeId = new EventAttendeeId(event.getEventId(), currentUser.getUserId());
        if (eventAttendeeRepository.existsById(attendeeId)) {
            return; // Already joined
        }
        EventAttendee eventAttendee = new EventAttendee();
        eventAttendee.setId(attendeeId);
        eventAttendee.setEvent(event);
        eventAttendee.setUser(currentUser);
        eventAttendeeRepository.save(eventAttendee);
    }

    @Override
    @Transactional
    public void leaveEvent(Long eventId) throws ResourceNotFoundException { // Added throws clause
        User currentUser = getCurrentAuthenticatedUser();
        // Check if event exists before creating ID for deletion
        if (!eventRepository.existsById(eventId)) {
            throw new ResourceNotFoundException("Event", "id", eventId);
        }
        EventAttendeeId attendeeId = new EventAttendeeId(eventId, currentUser.getUserId());
        // Optional: Check if the user is actually attending before trying to delete
        // if (!eventAttendeeRepository.existsById(attendeeId)) {
        //     // User wasn't attending, maybe log or return specific status
        //     return;
        // }
        eventAttendeeRepository.deleteById(attendeeId);
    }

    private EventDto mapEventToDto(Event event, User currentUser) {
        EventDto dto = new EventDto();
        BeanUtils.copyProperties(event, dto);
        dto.setId(event.getEventId());
        if (event.getCreatedBy() != null) {
            UserSummaryDto creatorDto = new UserSummaryDto();
            BeanUtils.copyProperties(event.getCreatedBy(), creatorDto);
            creatorDto.setId(event.getCreatedBy().getUserId());
            dto.setCreatedBy(creatorDto);
        }
        if (event.getCollege() != null) {
            dto.setCollegeId(event.getCollege().getCollegeId());
        }
        if (event.getAttendees() != null) {
            dto.setAttendees(event.getAttendees().stream().map(ea -> {
                UserSummaryDto attendeeUserDto = new UserSummaryDto();
                // Check if user is null before copying properties
                if (ea.getUser() != null) {
                    BeanUtils.copyProperties(ea.getUser(), attendeeUserDto);
                    attendeeUserDto.setId(ea.getUser().getUserId());
                }
                return attendeeUserDto;
            }).collect(Collectors.toList()));
        }
        // Check if currentUser is null before checking attendance
        if(currentUser != null) {
            dto.setAttending(eventAttendeeRepository.existsByIdEventIdAndIdUserId(event.getEventId(), currentUser.getUserId()));
        } else {
            dto.setAttending(false); // Or handle as appropriate if user must be logged in to see this
        }
        return dto;
    }
}
