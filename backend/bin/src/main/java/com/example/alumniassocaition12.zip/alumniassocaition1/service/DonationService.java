package com.example.alumniassocaition1.service;

public interface DonationService {
}
